Arctictut Template for DokuWiki

Based on the Arctic Template by Michael Klier

All documentation for the Arctic Template is available online at:
http://dokuwiki.org/template:arctictut

(c) 2013 by Laura Eun <laura.eun@live.de>
See LICENSE for license info.
